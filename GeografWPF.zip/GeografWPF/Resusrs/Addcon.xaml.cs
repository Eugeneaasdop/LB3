﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using GeografWPF.Classes;

namespace GeografWPF.Resusrs
{
    /// <summary>
    /// Логика взаимодействия для Addcon.xaml
    /// </summary>
    public partial class Addcon : Page
    {
        private Country _currentCountry = new Country();
        public Addcon(Country selectedCountry)
        {
            InitializeComponent();
            if (selectedCountry != null)
            {
                _currentCountry = selectedCountry;
                Titletxt.Text = "Изменение страны";
                btnAddCountry.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentCountry;
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Class.ClassFrame.frmObj.Navigate(new PageCountry());
        }

        private void btnAddCountry_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentCountry.Name)) error.AppendLine("Укажите Страну");
            if (string.IsNullOrWhiteSpace(_currentCountry.Capital)) error.AppendLine("Укажите Столицу");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentCountry.Square))) error.AppendLine("Укажите площадь");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentCountry.Id_Population))) error.AppendLine("Укажите код популяции");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentCountry.Id_region))) error.AppendLine("Укажите код региона");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentCountry.Id_country == 0)
            {
                GeografyEntities1.GetContext().Country.Add(_currentCountry);
                try
                {
                    GeografyEntities1.GetContext().SaveChanges();
                    Class.ClassFrame.frmObj.Navigate(new PageCountry());
                    MessageBox.Show("Новая страна успешно добавлена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    GeografyEntities1.GetContext().SaveChanges();
                    Class.ClassFrame.frmObj.Navigate(new PageCountry());
                    MessageBox.Show("Страна успешна изменена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
